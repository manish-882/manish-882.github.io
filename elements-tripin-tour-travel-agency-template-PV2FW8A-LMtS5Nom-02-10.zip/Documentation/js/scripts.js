$(document).ready(function(){
    
    $("#single_documentation .left .ul .li").on("click", function(e){
        e.preventDefault();
        var thisLi = $(this),
            thisIndex = thisLi.index(),
            thisContent = $("#single_documentation .right .content").eq(thisIndex);
        
        $("#single_documentation .left .ul .li").not(thisLi).removeClass("active");
        thisLi.addClass("active");
        $("#single_documentation .right .content").not(thisContent).hide();
        thisContent.fadeIn();
    });
    
});